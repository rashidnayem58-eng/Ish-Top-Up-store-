# ISH TOP UP STORE — storefront prototype

This is a front-end demo, not yet a production shop. Orders are stored in the visitor's local browser only; the Admin Demo panel only sees orders on the same browser. Email notification, shared database, secure admin authentication, and real payments are **not connected**.

## Deploy a preview for free (Cloudflare Pages)
1. Unzip this folder.
2. A trusted adult should help create a GitHub account/repository if needed.
3. Upload the files (`index.html`, `styles.css`, `app.js`) to a repository.
4. In Cloudflare, open Workers & Pages → Create application → Pages → Connect to Git.
5. Select the repo; leave the build command blank and the output directory as the repository root (`/`). Deploy.
6. Your preview will be on a `*.pages.dev` address.

Before using it for real customers, configure a proper backend/database, authenticated admin panel, email service and payment workflow. Never expose service secrets in browser JavaScript. Get an adult to help manage accounts, money, customer data and merchant terms.

## Included catalog
- Roblox: 100/200/500/1000/2000/5000 Robux; group payout; Roblox Plus availability should be added as a custom product later.
- MLBB BD server: prices from the provided screenshot. Memberships marked up by ৳20; diamonds kept at supplier price. 500+500 package shown unavailable.
